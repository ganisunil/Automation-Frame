package com.poc.base;

import org.openqa.selenium.WebDriver;


public class BaseInitialiser {
		
	public static WebDriver driver;
}
